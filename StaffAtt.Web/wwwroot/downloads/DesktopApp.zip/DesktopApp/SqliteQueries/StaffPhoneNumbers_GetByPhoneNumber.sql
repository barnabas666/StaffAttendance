﻿SELECT Id, StaffId, PhoneNumberId
FROM StaffPhoneNumbers
WHERE PhoneNumberId = @phoneNumberId;