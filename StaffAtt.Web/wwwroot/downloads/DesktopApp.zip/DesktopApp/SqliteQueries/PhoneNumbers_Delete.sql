﻿DELETE FROM PhoneNumbers
WHERE Id = @phoneNumberId;