﻿DELETE FROM Aliases
WHERE Id = @id;