﻿DELETE FROM Addresses
WHERE Id = @id;