﻿INSERT INTO "Aliases" ("Alias", "PIN")
VALUES (@alias, @pIN)
RETURNING "Id";
