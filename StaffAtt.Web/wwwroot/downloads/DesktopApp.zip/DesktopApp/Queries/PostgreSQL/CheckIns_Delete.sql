﻿DELETE FROM "CheckIns"
WHERE "StaffId" = @staffId;
