﻿DELETE FROM "StaffPhoneNumbers"
WHERE "StaffId" = @staffId
  AND "PhoneNumberId" = @phoneNumberId;
