﻿SELECT "EmailAddress"
FROM "Staffs"
WHERE "Id" = @id;
