﻿SELECT "Id"
FROM "PhoneNumbers"
WHERE "PhoneNumber" = @phoneNumber;
