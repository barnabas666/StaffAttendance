﻿INSERT INTO "StaffPhoneNumbers" ("StaffId", "PhoneNumberId")
VALUES (@staffId, @phoneNumberId);
