﻿SELECT "Id", "Title", "Description"
FROM "Departments";
