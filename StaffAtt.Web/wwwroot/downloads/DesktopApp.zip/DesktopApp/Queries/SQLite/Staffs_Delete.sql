﻿DELETE FROM Staffs
WHERE Id = @staffId;