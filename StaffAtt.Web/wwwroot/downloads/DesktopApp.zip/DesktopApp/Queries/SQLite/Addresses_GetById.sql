﻿SELECT Id, Street, City, Zip, State
FROM Addresses
WHERE Id = @id;