﻿UPDATE Aliases
SET PIN = @pIN
WHERE Id = @id;