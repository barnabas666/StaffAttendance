﻿SELECT Id, Alias
FROM Aliases
WHERE Alias = @alias AND PIN = @pIN;
